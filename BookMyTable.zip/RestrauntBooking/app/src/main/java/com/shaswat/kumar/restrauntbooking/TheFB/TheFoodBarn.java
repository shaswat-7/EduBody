package com.shaswat.kumar.restrauntbooking.TheFB;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.shaswat.kumar.restrauntbooking.R;

public class TheFoodBarn extends AppCompatActivity {

    LinearLayout review;
    LinearLayout menu;
    LinearLayout bookTable;
    LinearLayout contact;


    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_food_barn);

        review = findViewById(R.id.Review);
        menu = findViewById(R.id.Menu);
        bookTable = findViewById(R.id.BookTable);
        contact = findViewById(R.id.Contact_Us);

        toolbar = findViewById(R.id.toolbarFB);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("The Food Barn");




        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),ReviewFB.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), MenuFB.class));

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Tablebooking.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(TheFoodBarn.this);
                dialog.setContentView(R.layout.contact_us_fb);

                TextView fbemail = dialog.findViewById(R.id.thefbemail);
                TextView fbNumber = dialog.findViewById(R.id.thefbNumber);

                fbemail.setText("thefoodbarn@gmail.com");
                fbNumber.setText("1234567899");


                dialog.show();


            }
        });

    }
}
