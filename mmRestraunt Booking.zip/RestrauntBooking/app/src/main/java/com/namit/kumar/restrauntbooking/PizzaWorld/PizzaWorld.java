package com.namit.kumar.restrauntbooking.PizzaWorld;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.namit.kumar.restrauntbooking.R;

public class PizzaWorld extends AppCompatActivity {


    LinearLayout review;
    LinearLayout menu;
    LinearLayout bookTable;
    LinearLayout contact;

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_world);


        review = findViewById(R.id.ReviewPW);
        menu = findViewById(R.id.MenuPW);
        bookTable = findViewById(R.id.BookTablePW);
        contact = findViewById(R.id.Contact_UsPW);

        toolbar = findViewById(R.id.toolbarPW);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Pizza World");

        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), ReviewPW.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), MenuPW.class));

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               startActivity(new Intent(getApplicationContext() , BookTablePW.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(PizzaWorld.this);
                dialog.setContentView(R.layout.contact_us_fb);

                TextView fbemail = dialog.findViewById(R.id.thefbemail);
                TextView fbNumber = dialog.findViewById(R.id.thefbNumber);

                fbemail.setText("pizzaworld@gmail.com");
                fbNumber.setText("1234567898");


                dialog.show();


            }
        });
    }
}
