package com.namit.kumar.restrauntbooking.ZoloCrust;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.namit.kumar.restrauntbooking.R;

public class ZoloCrust extends AppCompatActivity {


    LinearLayout reviewZC;
    LinearLayout menuZC;
    LinearLayout bookTableZC;
    LinearLayout contactZC;

    Toolbar toolbarZC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zolo_crust);


        reviewZC = findViewById(R.id.ReviewZC);
        menuZC = findViewById(R.id.MenuZC);
        bookTableZC = findViewById(R.id.BookTableZC);
        contactZC = findViewById(R.id.Contact_UsZC);

        toolbarZC = findViewById(R.id.toolbarZC);
        setSupportActionBar(toolbarZC);
        getSupportActionBar().setTitle("Zolo Crust");

        reviewZC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), ReviewZC.class));

            }
        });

        menuZC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),MenuZC.class));
            }
        });

        bookTableZC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext() , TableBookingZC.class));
            }
        });

        contactZC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(ZoloCrust.this);
                dialog.setContentView(R.layout.contact_us_fb);

                TextView fbemail = dialog.findViewById(R.id.thefbemail);
                TextView fbNumber = dialog.findViewById(R.id.thefbNumber);

                fbemail.setText("zolocrust@gmail.com");
                fbNumber.setText("1234567899");


                dialog.show();


            }
        });

    }
}
