package com.namit.kumar.restrauntbooking.TenTwisters;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.namit.kumar.restrauntbooking.R;
import com.namit.kumar.restrauntbooking.TheFB.Tablebooking;
import com.namit.kumar.restrauntbooking.TheFB.TheFoodBarn;

public class TenTwisters extends AppCompatActivity {

    LinearLayout review;
    LinearLayout menu;
    LinearLayout bookTable;
    LinearLayout contact;
    int a,b,c,d,e,f;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ten_twisters);

        review = findViewById(R.id.ReviewTT);
        menu = findViewById(R.id.MenuTT);
        bookTable = findViewById(R.id.BookTableTT);
        contact = findViewById(R.id.Contact_UsTT);

        toolbar = findViewById(R.id.toolbarTT);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Ten Twisters");


        Intent i5 =getIntent();
        a=i5.getIntExtra("first",0);
        b=i5.getIntExtra("second",0);
        c=i5.getIntExtra("third",0);
        d=i5.getIntExtra("fourth",0);
        e=i5.getIntExtra("fifth",0);
        f=i5.getIntExtra("sixth",0);



        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), ReviewTT.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),MenuTT.class));

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i6 =new Intent(TenTwisters.this, Tablebooking.class);
                i6.putExtra("q",a);
                i6.putExtra("w",b);
                i6.putExtra("e",c);
                i6.putExtra("r",d);
                i6.putExtra("t",e);
                i6.putExtra("y",f);
                startActivity(i6);
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(TenTwisters.this);
                dialog.setContentView(R.layout.contact_us_fb);

                TextView fbemail = dialog.findViewById(R.id.thefbemail);
                TextView fbNumber = dialog.findViewById(R.id.thefbNumber);

                fbemail.setText("tentwisters@gmail.com");
                fbNumber.setText("1234567898");


                dialog.show();


            }
        });



    }
}
