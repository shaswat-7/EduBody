package com.namit.kumar.restrauntbooking.TheFB;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.namit.kumar.restrauntbooking.Model.Data;
import com.namit.kumar.restrauntbooking.R;
import com.namit.kumar.restrauntbooking.RestaurantOpt;

import java.text.DateFormat;
import java.util.Date;

public class Tablebooking extends AppCompatActivity {

    int isClickedDummy1,isClickedDummy2,isClickedDummy3,isClickedDummy4,isClickedDummy5,isClickedDummy6;
    CardView t1,t2,t3,t4,t5,t6;

    Button Buttoncnf;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;

    private int count=0;

    public String table_no;

    String Rest_name;
    int x1,x2,x3,x4,x5,x6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tablebooking);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();


        Buttoncnf = findViewById(R.id.confirmseatFB);

        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);

        mBookingDatabase.keepSynced(true);


        Data tData = new Data();




        t1 =(CardView)findViewById(R.id.table1);
        t2 =(CardView)findViewById(R.id.table2);
        t3 =(CardView)findViewById(R.id.table3);
        t4 =(CardView)findViewById(R.id.table4);
        t5 =(CardView)findViewById(R.id.table5);
        t6 =(CardView)findViewById(R.id.table6);


        Intent i7 = getIntent();
        x1 =i7.getIntExtra("q",0);
        x2 =i7.getIntExtra("w",0);
        x3 =i7.getIntExtra("e",0);
        x4 =i7.getIntExtra("r",0);
        x5 =i7.getIntExtra("t",0);
        x6 =i7.getIntExtra("y",0);


        if(x1==1) {
            t1.setCardBackgroundColor(Color.RED);
        }
        if(x2==1) {
            t2.setCardBackgroundColor(Color.RED);
        }
        if(x3==1) {
            t3.setCardBackgroundColor(Color.RED);
        }
        if(x4==1) {
            t4.setCardBackgroundColor(Color.RED);
        }
        if(x5==1) {
            t5.setCardBackgroundColor(Color.RED);
        }
        if(x6==1) {
            t6.setCardBackgroundColor(Color.RED);
        }

        t1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x1==0) {
                    t1.setCardBackgroundColor(Color.RED);
                    table_no= "1";
                    isClickedDummy1 = 1;
                    Information();

                } else {
                    t1.setCardBackgroundColor(Color.WHITE);

                    isClickedDummy1 = 0;
                }
            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x2==0) {
                    t2.setCardBackgroundColor(Color.RED);

                    table_no = "2";
                    isClickedDummy2 = 1;
                    Information();


                } else {
                    t2.setCardBackgroundColor(Color.WHITE);
                    isClickedDummy2 = 0;
                }
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x3==0) {
                    t3.setCardBackgroundColor(Color.RED);
                    table_no = "3";
                    isClickedDummy3 = 1;
                    Information();


                } else {
                    t3.setCardBackgroundColor(Color.WHITE);
                    isClickedDummy3 = 0;
                }
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x4==0) {
                    t4.setCardBackgroundColor(Color.RED);
                    table_no = "4";
                    isClickedDummy4 = 1;
                    Information();


                } else {
                    t4.setCardBackgroundColor(Color.WHITE);
                    isClickedDummy4 = 0;
                }
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x5==0) {
                    t5.setCardBackgroundColor(Color.RED);
                    table_no = "5";
                    isClickedDummy5 = 1;
                    Information();


                } else {
                    t5.setCardBackgroundColor(Color.WHITE);
                    isClickedDummy5 = 0;
                }
            }
        });

        t6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(x6==0) {
                    t6.setCardBackgroundColor(Color.RED);
                    table_no = "6";
                    isClickedDummy6 = 1;
                    Information();


                } else {
                    t6.setCardBackgroundColor(Color.WHITE);
                    isClickedDummy6 = 0;
                }
            }
        });

//        t7.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy7) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "7";
//                    Information();
//
//                    isClickedDummy7 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy7 = true;
//                }
//            }
//        });
//        t8.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy8) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "8";
//                    Information();
//
//                    isClickedDummy8 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy8 = true;
//                }
//            }
//        });
//        t9.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy9) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "9";
//                    Information();
//
//                    isClickedDummy9 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy9 = true;
//                }
//            }
//        });
//
//
//
//        t10.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy10) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "10";
//                    Information();
//
//                    isClickedDummy10 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy10 = true;
//                }
//            }
//        });
//
//        t11.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy11) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "11";
//                    Information();
//
//                    isClickedDummy11 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy11 = true;
//                }
//            }
//        });
//
//        t12.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                if(isClickedDummy12) {
//                    v.setBackgroundColor(Color.parseColor("#FF0000"));
//                    table_no = "12";
//                    Information();
//
//                    isClickedDummy12 = false;
//                } else {
//                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
//                    isClickedDummy12 = true;
//                }
//            }
//        });


Buttoncnf.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        if(count>0){


            Toast.makeText(Tablebooking.this, "BOOKING CONFIRMED", Toast.LENGTH_SHORT).show();

            Intent i =new Intent(Tablebooking.this,RestaurantOpt.class);
            i.putExtra("one",isClickedDummy1);
            i.putExtra("two",isClickedDummy2);
            i.putExtra("three",isClickedDummy3);
            i.putExtra("four",isClickedDummy4);
            i.putExtra("five",isClickedDummy5);
            i.putExtra("six",isClickedDummy6);
            startActivity(i);

        }

        else{

            Toast.makeText(Tablebooking.this, "No Table Booked", Toast.LENGTH_SHORT).show();
        }


    }
});



    }


   public void Information(){





       final Dialog dialog = new Dialog(this);

       dialog.setContentView(R.layout.customer_informtion);



       final EditText Name = dialog.findViewById(R.id.amount_edt);

       final EditText Time = dialog.findViewById(R.id.Time_edt);
       final EditText order = dialog.findViewById(R.id.order_edt);

       Button btnSave = dialog.findViewById(R.id.confirm);
       Button btnCancel = dialog.findViewById(R.id.btnCancel);

       dialog.show();

       btnSave.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               String name = "The Food Barn";

               if(TextUtils.isEmpty(name)){
                   Name.setError("Required Field..");
                   return;
               }


               String time = Time.getText().toString().trim();
               if (TextUtils.isEmpty(time)){

                   Time.setError("REQUIRED..");

                   return;

               }

               String Order = order.getText().toString().trim();


               String id = mBookingDatabase.push().getKey();//creates a random id in mIncomeDatabase

               String mDate = DateFormat.getDateInstance().format(new Date());

               Data data = new Data(name,id,mDate,table_no,Order,time);

               mBookingDatabase.child(id).setValue(data);

               Toast.makeText(getApplicationContext(),"Table Booked", Toast.LENGTH_SHORT).show();



               count++;
               dialog.dismiss();




           }
       });

       btnCancel.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {


               dialog.dismiss();

           }
       });


    }



}
