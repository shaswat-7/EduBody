package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private EditText email;
    private EditText password;
    private Button btnLogin;
    private TextView forgetPass;
    private TextView singnUp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        email = findViewById(R.id.email_login);
        password = findViewById(R.id.password_login);
        btnLogin = findViewById(R.id.btn_login);
        forgetPass = findViewById(R.id.forgetPassword_login);
        singnUp = findViewById(R.id.signup_login);

    }
}
