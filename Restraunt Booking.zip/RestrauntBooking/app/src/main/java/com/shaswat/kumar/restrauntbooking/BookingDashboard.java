package com.shaswat.kumar.restrauntbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shaswat.kumar.restrauntbooking.Model.Data;

public class BookingDashboard extends AppCompatActivity {

    private RecyclerView recyclerView;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_dashboard);

        mAuth = FirebaseAuth.getInstance();

        FirebaseUser muser = mAuth.getCurrentUser();

        String uid  = muser.getUid();

        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);

        recyclerView = findViewById(R.id.recycler_id_expense);

        //this is done for managing recycler view



        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());

        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);




    }


    public void onStart() {
        super.onStart();


        FirebaseRecyclerAdapter<Data, MyViewHolder>adapter = new FirebaseRecyclerAdapter<Data, MyViewHolder>
                (
                        Data.class,
                        R.layout.bookingcontent,
                        MyViewHolder.class,
                        mBookingDatabase

                )
        {
            @Override
            protected void populateViewHolder(MyViewHolder myViewHolder, Data data, int i) {


                myViewHolder.setName(data.getName());
                 myViewHolder.setDate(data.getDate());


            }
        };

        recyclerView.setAdapter(adapter);
    }

    private class MyViewHolder extends RecyclerView.ViewHolder {

        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
        }

        private void setName(String name){

            TextView myName = mView.findViewById(R.id.note_text_expense);
            myName.setText(name);
        }

//        private void setAmount(String){
//
//            TextView myNote = mView.findViewById(R.id.note_text_expense);
//            myNote.setText(note);
//        }

        private void setDate(String date){

            TextView myDate = mView.findViewById(R.id.date_text_expense);
            myDate.setText(date);
        }
    }
}
