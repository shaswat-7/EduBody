package com.shaswat.kumar.restrauntbooking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

public class Delhi extends AppCompatActivity {

    Toolbar toolbar;

    Spinner spinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delhi);

        toolbar = findViewById(R.id.delhi);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Delhi");

        spinner2 = findViewById(R.id.spinner2);


        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String selectedItem = adapterView.getItemAtPosition(i).toString();

                if (selectedItem.equals("Jaipur")) {

                    startActivity(new Intent(getApplicationContext(),RestaurantOpt.class));


                }

                if (selectedItem.equals("Delhi")) {

                    Toast.makeText(getApplicationContext(),"Delhi",Toast.LENGTH_SHORT).show();
                }

                if(selectedItem.equals("Udaipur")){


                    startActivity(new Intent(getApplicationContext(),Udaipur.class));


                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }
}
