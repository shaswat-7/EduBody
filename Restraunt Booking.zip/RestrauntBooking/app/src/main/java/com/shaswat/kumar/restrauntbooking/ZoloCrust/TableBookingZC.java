package com.shaswat.kumar.restrauntbooking.ZoloCrust;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaswat.kumar.restrauntbooking.Model.Data;
import com.shaswat.kumar.restrauntbooking.PizzaWorld.BookTablePW;
import com.shaswat.kumar.restrauntbooking.R;
import com.shaswat.kumar.restrauntbooking.RestaurantOpt;

import java.text.DateFormat;
import java.util.Date;

public class TableBookingZC extends AppCompatActivity {



    Boolean isClickedDummy1,isClickedDummy2,isClickedDummy3,isClickedDummy4,isClickedDummy5,isClickedDummy6,isClickedDummy7,isClickedDummy8,isClickedDummy9,isClickedDummy10,isClickedDummy11,isClickedDummy12;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;

    Button buttoncnf;


    int count=0;
    public String table_noZC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_booking_zc);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();


        buttoncnf = findViewById(R.id.confirmseatZC);

        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);

        mBookingDatabase.keepSynced(true);

        isClickedDummy1 = true;
        isClickedDummy2 = true;
        isClickedDummy3 = true;
        isClickedDummy4 = true;
        isClickedDummy5 = true;
        isClickedDummy6 = true;
        isClickedDummy7 = true;
        isClickedDummy8 = true;
        isClickedDummy9 = true;
        isClickedDummy10 = true;
        isClickedDummy11 = true;
        isClickedDummy12 = true;


        CardView t1 =(CardView)findViewById(R.id.table1ZC);
        CardView t2 =(CardView)findViewById(R.id.table2ZC);
        CardView t3 =(CardView)findViewById(R.id.table3ZC);
        CardView t4 =(CardView)findViewById(R.id.table4ZC);
        CardView t5 =(CardView)findViewById(R.id.table5ZC);
        CardView t6 =(CardView)findViewById(R.id.table6ZC);
        CardView t7 =(CardView)findViewById(R.id.table7ZC);
        CardView t8 =(CardView)findViewById(R.id.table8ZC);
        CardView t9 =(CardView)findViewById(R.id.table9ZC);
        CardView t10 =(CardView)findViewById(R.id.table10ZC);
        CardView t11 =(CardView)findViewById(R.id.table11ZC);
        CardView t12 =(CardView)findViewById(R.id.table12ZC) ;

        t1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy1) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "1";
                    Information();
                    isClickedDummy1 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy1 = true;
                }
            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy2) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));

                    table_noZC = "2";
                    Information();

                    isClickedDummy2 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy2 = true;
                }
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy3) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "3";
                    Information();
                    isClickedDummy3 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy3 = true;
                }
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy4) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "4";
                    Information();
                    isClickedDummy4 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy4 = true;
                }
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy5) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "5";
                    Information();
                    isClickedDummy5 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy5 = true;
                }
            }
        });

        t6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy6) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "6";
                    Information();
                    isClickedDummy6 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy6 = true;
                }
            }
        });

        t7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy7) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "7";
                    Information();
                    isClickedDummy7 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy7 = true;
                }
            }
        });
        t8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy8) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "8";
                    Information();
                    isClickedDummy8 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy8 = true;
                }
            }
        });
        t9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy9) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "9";
                    Information();
                    isClickedDummy9 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy9 = true;
                }
            }
        });



        t10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy10) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "10";
                    Information();
                    isClickedDummy10 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy10 = true;
                }
            }
        });

        t11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy11) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "11";
                    Information();
                    isClickedDummy11 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy11 = true;
                }
            }
        });

        t12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy12) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noZC= "12";
                    Information();
                    isClickedDummy12 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy12 = true;
                }
            }
        });

        buttoncnf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttoncnf.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(count>0){
                            Toast.makeText(TableBookingZC.this, "BOOKING CONFIRMED", Toast.LENGTH_SHORT).show();
                            //                Toast.makeText(BookTablePW.this, "BOOKING CONFIRMED", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), RestaurantOpt.class));
                        }
                        else{

                            Toast.makeText(TableBookingZC.this, "No Table Booked", Toast.LENGTH_SHORT).show();

                        }




                    }
                });

            }
        });
    }

    public void Information(){

        final Dialog dialog = new Dialog(this);

        dialog.setContentView(R.layout.customer_informtion);



        final EditText Name = dialog.findViewById(R.id.amount_edt);

        final EditText Time = dialog.findViewById(R.id.Time_edt);
        final EditText order = dialog.findViewById(R.id.order_edt);

        Button btnSave = dialog.findViewById(R.id.confirm);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        dialog.show();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = "ZOLO CRUST";

                if(TextUtils.isEmpty(name)){
                    Name.setError("Required Field..");
                    return;
                }


                String time = Time.getText().toString().trim();
                if (TextUtils.isEmpty(time)){

                    Time.setError("REQUIRED..");

                    return;

                }

                String Order = order.getText().toString().trim();


                String id = mBookingDatabase.push().getKey();//creates a random id in mIncomeDatabase

                String mDate = DateFormat.getDateInstance().format(new Date());

                Data data = new Data(name,id,mDate,table_noZC,Order,time);

                mBookingDatabase.child(id).setValue(data);

                Toast.makeText(getApplicationContext(),"Table Booked", Toast.LENGTH_SHORT).show();



                count++;
                dialog.dismiss();



            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });
    }
}
