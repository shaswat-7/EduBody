package com.shaswat.kumar.restrauntbooking;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.shaswat.kumar.restrauntbooking.PizzaWorld.PizzaWorld;
import com.shaswat.kumar.restrauntbooking.TenTwisters.TenTwisters;
import com.shaswat.kumar.restrauntbooking.TheFB.TheFoodBarn;
import com.shaswat.kumar.restrauntbooking.ZoloCrust.ZoloCrust;

public class RestaurantOpt extends AppCompatActivity {

    CardView Restaurant1;
    CardView Restaurant2;
    CardView Restaurant3;
    CardView Restaurant4;

    Toolbar toolbar;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;
    private DatabaseReference mReviewfb;

    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_opt);

        toolbar = findViewById(R.id.toolbar_note);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Restaurants");

        Restaurant1 = findViewById(R.id.restaurant1);
        Restaurant2 = findViewById(R.id.restaurant2);
        Restaurant3 = findViewById(R.id.restaurant3);

        Restaurant4 = findViewById(R.id.restaurant4);


        spinner = findViewById(R.id.spinner1);

      spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

              String selectedItem = adapterView.getItemAtPosition(i).toString();

              if (selectedItem.equals("Jaipur")) {

                  Toast.makeText(getApplicationContext(), "Jaipur", Toast.LENGTH_SHORT).show();


              }

              if (selectedItem.equals("Delhi")) {

                  startActivity(new Intent(getApplicationContext(), Delhi.class));
              }

              if(selectedItem.equals("Udaipur")){

                  startActivity(new Intent(getApplicationContext(),Udaipur.class));
              }

          }

          @Override
          public void onNothingSelected(AdapterView<?> adapterView) {

          }
      });





        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();

//        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);
//
//        mReviewfb = FirebaseDatabase.getInstance().getReference().child("ReviewfbData").child(uid);
//
//        mBookingDatabase.keepSynced(true);
//        mReviewfb.keepSynced(true);


        Restaurant1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), TheFoodBarn.class));

            }
        });

        Restaurant2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              startActivity(new Intent(getApplicationContext(), TenTwisters.class));

            }
        });

        Restaurant3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


              startActivity(new Intent(getApplicationContext(), ZoloCrust.class));


            }
        });

        Restaurant4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PizzaWorld.class));
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuopt,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.bookdash:

                startActivity(new Intent(getApplicationContext(),BookingDashboard.class));
                break;

            case R.id.logout:

                new AlertDialog.Builder(this).setTitle("Confirm..").setMessage("Are You Sure?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mAuth.signOut();
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    }
                }).setNegativeButton("No",null).show();

                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
