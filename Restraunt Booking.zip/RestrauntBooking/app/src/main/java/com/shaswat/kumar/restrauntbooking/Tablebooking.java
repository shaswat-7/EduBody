package com.shaswat.kumar.restrauntbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaswat.kumar.restrauntbooking.Model.Data;

import java.text.DateFormat;
import java.util.Date;
import java.util.jar.Attributes;

public class Tablebooking extends AppCompatActivity {


    TextView chair1;
    TextView chair2;
    TextView chair3;
    TextView chair4;
    TextView chair5;
    TextView chair6;

    Boolean C1isbooked;
    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;



    String Rest_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tablebooking);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();



        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);

        mBookingDatabase.keepSynced(true);


        chair1 = findViewById(R.id.chair1);
        chair2 = findViewById(R.id.chair2);
        chair3 = findViewById(R.id.chair3);
        chair4 = findViewById(R.id.chair4);
        chair5 = findViewById(R.id.chair5);
        chair6 = findViewById(R.id.chair6);


        Intent intent = getIntent();

        Rest_name = intent.getStringExtra("Rest1");

//        if(Rest_name == "Restaurant1"){
//
//
//
//        }
//
//        if(Rest_name == "Restaurant2"){
//
//
//
//        }
//
//        if(Rest_name == "Restaurant3"){
//
//
//
//        }
//
//
//        chair1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//
//
//                Toast.makeText(getApplicationContext(),"Clicked",Toast.LENGTH_SHORT).show();
//
//                Information();
//
//                if(C1isbooked)
//                    chair1.setBackgroundColor(R.drawable.booktable);
//
//
//
//            }
//        });
//
//
//        chair2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//
//        chair3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//
//        chair4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        chair5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        chair6.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });





    }


   public void Information(){




//
//       final Dialog dialog = new Dialog(this);
//
//       dialog.setContentView(R.layout.customer_informtion);
//
//
//
//       final EditText Name = dialog.findViewById(R.id.amount_edt);
//
//       Button btnSave = dialog.findViewById(R.id.confirm);
//       Button btnCancel = dialog.findViewById(R.id.btnCancel);
//
//       dialog.show();
//
//       btnSave.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View view) {
//
//               String name = Name.getText().toString().trim();
//
//               if(TextUtils.isEmpty(name)){
//                   Name.setError("Required Field..");
//                   return;
//               }
//
//
//               String id = mBookingDatabase.push().getKey();//creates a random id in mIncomeDatabase
//
//               String mDate = DateFormat.getDateInstance().format(new Date());
//
//               Data data = new Data(name,id,mDate);
//
//               mBookingDatabase.child(id).setValue(data);
//
//               Toast.makeText(getApplicationContext(),"Table Booked", Toast.LENGTH_SHORT).show();
//
//               C1isbooked=true;
//
//               dialog.dismiss();
//
//
//
//           }
//       });


    }



}
