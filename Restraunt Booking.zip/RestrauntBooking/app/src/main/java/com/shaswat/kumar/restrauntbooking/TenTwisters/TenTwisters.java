package com.shaswat.kumar.restrauntbooking.TenTwisters;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.shaswat.kumar.restrauntbooking.R;
import com.shaswat.kumar.restrauntbooking.TheFB.TheFoodBarn;

public class TenTwisters extends AppCompatActivity {

    LinearLayout review;
    LinearLayout menu;
    LinearLayout bookTable;
    LinearLayout contact;

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ten_twisters);

        review = findViewById(R.id.ReviewTT);
        menu = findViewById(R.id.MenuTT);
        bookTable = findViewById(R.id.BookTableTT);
        contact = findViewById(R.id.Contact_UsTT);

        toolbar = findViewById(R.id.toolbarTT);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Ten Twisters");




        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), ReviewTT.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),MenuTT.class));

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext() , TableBookingTT.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(TenTwisters.this);
                dialog.setContentView(R.layout.contact_us_fb);

                TextView fbemail = dialog.findViewById(R.id.thefbemail);
                TextView fbNumber = dialog.findViewById(R.id.thefbNumber);

                fbemail.setText("tentwisters@gmail.com");
                fbNumber.setText("1234567898");


                dialog.show();


            }
        });



    }
}
