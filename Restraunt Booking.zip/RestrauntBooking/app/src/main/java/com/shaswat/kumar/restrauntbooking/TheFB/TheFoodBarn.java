package com.shaswat.kumar.restrauntbooking.TheFB;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.shaswat.kumar.restrauntbooking.R;
import com.shaswat.kumar.restrauntbooking.Tablebooking;

public class TheFoodBarn extends AppCompatActivity {

    TextView review;
    TextView menu;
    TextView bookTable;
    TextView contact;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_food_barn);

        review = findViewById(R.id.Review);
        menu = findViewById(R.id.Menu);
        bookTable = findViewById(R.id.BookTable);
        contact = findViewById(R.id.Contact_Us);




        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),ReviewFB.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Tablebooking.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
