package com.aman1.kumar.restrauntbooking.PizzaWorld;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.aman1.kumar.restrauntbooking.R;

public class MenuPW extends AppCompatActivity {

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_pw);


        toolbar = findViewById(R.id.menuPWtool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("MENU");
    }
}
