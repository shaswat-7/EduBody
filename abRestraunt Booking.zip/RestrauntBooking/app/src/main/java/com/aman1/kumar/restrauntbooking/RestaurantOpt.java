package com.aman1.kumar.restrauntbooking;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.aman1.kumar.restrauntbooking.PizzaWorld.PizzaWorld;
import com.aman1.kumar.restrauntbooking.TenTwisters.TenTwisters;
import com.aman1.kumar.restrauntbooking.TheFB.TheFoodBarn;
import com.aman1.kumar.restrauntbooking.ZoloCrust.ZoloCrust;

public class RestaurantOpt extends AppCompatActivity {

    CardView Restaurant1;
    CardView Restaurant2;
    CardView Restaurant3;
    CardView Restaurant4;
int t1,t2,t3,t4,t5,t6;
int c1,c2,c3,c4,c5,c6;
    Toolbar toolbar;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;
    private DatabaseReference mReviewfb;

    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_opt);

        toolbar = findViewById(R.id.toolbar_note);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Restaurants");

        Restaurant1 = findViewById(R.id.restaurant1);
        Restaurant2 = findViewById(R.id.restaurant2);
        Restaurant3 = findViewById(R.id.restaurant3);

        Restaurant4 = findViewById(R.id.restaurant4);


        spinner = findViewById(R.id.spinner1);

      spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

              String selectedItem = adapterView.getItemAtPosition(i).toString();

              if (selectedItem.equals("Jaipur")) {

                  Toast.makeText(getApplicationContext(), "Jaipur", Toast.LENGTH_SHORT).show();


              }

              if (selectedItem.equals("Delhi")) {

                  startActivity(new Intent(getApplicationContext(), Delhi.class));
              }

              if(selectedItem.equals("Udaipur")){

                  startActivity(new Intent(getApplicationContext(),Udaipur.class));
              }

          }

          @Override
          public void onNothingSelected(AdapterView<?> adapterView) {

          }
      });


        Intent i2 =getIntent();
        t1=i2.getIntExtra("one",0);
        t2=i2.getIntExtra("two",0);
        t3=i2.getIntExtra("three",0);
        t4=i2.getIntExtra("four",0);
        t5=i2.getIntExtra("five",0);
        t6=i2.getIntExtra("six",0);


        Intent i9 =getIntent();
        c1=i9.getIntExtra("one",0);
        c2=i9.getIntExtra("two",0);
        c3=i9.getIntExtra("three",0);
        c4=i9.getIntExtra("four",0);
        c5=i9.getIntExtra("five",0);
        c6=i9.getIntExtra("six",0);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();

//        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);
//
//        mReviewfb = FirebaseDatabase.getInstance().getReference().child("ReviewfbData").child(uid);
//
//        mBookingDatabase.keepSynced(true);
//        mReviewfb.keepSynced(true);


        Restaurant1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(RestaurantOpt.this,TheFoodBarn.class);
                i3.putExtra("first",c1);
                i3.putExtra("second",c2);
                i3.putExtra("third",c3);
                i3.putExtra("fourth",c4);
                i3.putExtra("fifth",c5);
                i3.putExtra("sixth",c6);
                startActivity(i3);

            }
        });

        Restaurant2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(RestaurantOpt.this,TenTwisters.class);
                i3.putExtra("first",t1);
                i3.putExtra("second",t2);
                i3.putExtra("third",t3);
                i3.putExtra("fourth",t4);
                i3.putExtra("fifth",t5);
                i3.putExtra("sixth",t6);
                startActivity(i3);

            }
        });

        Restaurant3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


              startActivity(new Intent(getApplicationContext(), ZoloCrust.class));


            }
        });

        Restaurant4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PizzaWorld.class));
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuopt,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.bookdash:

                startActivity(new Intent(getApplicationContext(),BookingDashboard.class));
                break;

            case R.id.logout:

                new AlertDialog.Builder(this).setTitle("Confirm..").setMessage("Are You Sure?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mAuth.signOut();
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    }
                }).setNegativeButton("No",null).show();

                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
