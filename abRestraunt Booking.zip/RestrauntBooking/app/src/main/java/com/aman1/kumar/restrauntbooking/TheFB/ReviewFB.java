package com.aman1.kumar.restrauntbooking.TheFB;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.aman1.kumar.restrauntbooking.Model.ReviewData;
import com.aman1.kumar.restrauntbooking.R;

import java.text.DateFormat;
import java.util.Date;

public class ReviewFB extends AppCompatActivity {

    EditText reviewedt;
    TextView submitfb;

    private RecyclerView reviewrecycler;

    FirebaseAuth mAuth;
    DatabaseReference mReviewfb;

    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_fb);

        reviewedt = findViewById(R.id.reviewfbedt);
        submitfb = findViewById(R.id.submitfb);

        toolbar = findViewById(R.id.reviewfbtool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("USER REVIEW");


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();

        mReviewfb = FirebaseDatabase.getInstance().getReference("users").child("ReviewfbData").child(uid);

        mReviewfb.keepSynced(true);




        reviewrecycler = findViewById(R.id.reviewRecyclerView);


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());

        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        reviewrecycler.setHasFixedSize(true);
        reviewrecycler.setLayoutManager(linearLayoutManager);

        Reviewinf();

    }

   public void Reviewinf(){

        submitfb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String rev = reviewedt.getText().toString().trim();

                if(TextUtils.isEmpty(rev)){
                    reviewedt.setError("Input before submit");
                    return;
                }

                String id = mReviewfb.push().getKey();//creates a random id in mIncomeDatabase

                String mDate = DateFormat.getDateInstance().format(new Date());

                ReviewData revdata = new ReviewData(rev,id,mDate);

                mReviewfb.child(id).setValue(revdata);

                Toast.makeText(getApplicationContext(),"Review done", Toast.LENGTH_SHORT).show();





            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<ReviewData , MyViewHolder> adapter = new FirebaseRecyclerAdapter<ReviewData, MyViewHolder>
                (
                        ReviewData.class,
                        R.layout.review_content,
                        MyViewHolder.class,
                        mReviewfb


                ) {
            @Override
            protected void populateViewHolder(MyViewHolder myViewHolder, ReviewData reviewData, int i) {

                myViewHolder.setReview(reviewData.getReview());
                myViewHolder.setDate(reviewData.getDate());

            }
        };

        reviewrecycler.setAdapter(adapter);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;

        }

        public void setReview(String rev){

            TextView revv = mView.findViewById(R.id.reviewtxt);
            revv.setText(rev);
        }

        private void setDate(String date){

            TextView Date = mView.findViewById(R.id.datetxt);
            Date.setText(date);
        }
    }
}
