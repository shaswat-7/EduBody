package com.example.bookmytable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mtable extends AppCompatActivity {
    int isDummy1;
    int x;


    CardView tab1;
    CardView tab2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mytable);
        tab1 = (CardView)findViewById(R.id.table1);
        tab2 =(CardView)findViewById(R.id.table2);




       Intent i3 = getIntent();
        x=i3.getIntExtra("abc",0);
        if(x==1) {
            tab1.setCardBackgroundColor(Color.RED);
        }


        tab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                if(x==0) {
                    tab1.setCardBackgroundColor(Color.RED);
                    isDummy1 = 1;

                }
                else {
                    tab1.setCardBackgroundColor(Color.WHITE);
                    isDummy1 = 0;
                }


            }
        });

        tab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i1 = new Intent(mtable.this,MainActivity.class);
                i1.putExtra("one",isDummy1);
                startActivity(i1);

            }
        });


    }



}
